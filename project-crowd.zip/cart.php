<?php include 'includes/header.php' ?>
<section class="table-bg">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 cart-xxl-12">
                <div class="cart10">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                            <div class="cart9">
                                <h2>YOUR CART</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                    </div>
                    <div class="row">
                    </div>
                    <div class="row">
                    </div>
                    <table class="table">
                        <thead>
                            <tr class="text-center cart8">
                                <th scope="col" class="cart7">PRODUCT INFORMATION</th>
                                <th scope="col">QTY</th>
                                <th scope="col">EACH</th>
                                <th scope="col">TOTAL</th>
                                <th scope="col" class="color">REMOVE ALL</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                                <td class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                                    <div class="cart1">
                                        <img src="images/sale-pro.png" class="img-fluid" alt="...">
                                        <div class="card-body mt-3 mx-3">
                                            <div class="cart2">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            </div>
                                            <div class="cart3 mt-2 ">
                                                <h2>PRODUCT</h2>
                                            </div>

                                            <div class="cart3">
                                                <p>$56.88</p>
                                            </div>

                                        </div>
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart4">
                                        <input type="number" placeholder="1">
                                        <span class="font-rem">Remove</span>
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart5">
                                        $4.87
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart5">
                                        $4.87
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart6">
                                        <a href="#">UPDATE</a>
                                    </div>
                                </td>

                            </tr>

                            <tr class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                                <td class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                                    <div class="cart1">
                                        <img src="images/sale-pro.png" class="img-fluid" alt="...">
                                        <div class="card-body mt-3 mx-3">
                                            <div class="cart2">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            </div>
                                            <div class="cart3 mt-2 ">
                                                <h2>PRODUCT</h2>
                                            </div>

                                            <div class="cart3">
                                                <p>$56.88</p>
                                            </div>

                                        </div>
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart4">
                                        <input type="number" placeholder="1">
                                        <span class="font-rem">Remove</span>
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart5">
                                        $4.87
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart5">
                                        $4.87
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart6">
                                        <a href="#">UPDATE</a>
                                    </div>
                                </td>

                            </tr>

                            <tr class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                                <td class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                                    <div class="cart1 ">
                                        <img src="images/sale-pro.png" class="img-fluid" alt="...">
                                        <div class="card-body mt-3 mx-3">
                                            <div class="cart2">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                            </div>
                                            <div class="cart3 mt-2 ">
                                                <h2>PRODUCT</h2>
                                            </div>

                                            <div class="cart3">
                                                <p>$56.88</p>
                                            </div>

                                        </div>
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart4">
                                        <input type="number" placeholder="1">
                                        <span class="font-rem">Remove</span>
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart5">
                                        $4.87
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart5">
                                        $4.87
                                    </div>
                                </td>
                                <td class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
                                    <div class="cart6">
                                        <a href="#">UPDATE</a>
                                    </div>
                                </td>

                            </tr>

                        </tbody>
                    </table>

                    <div class="row cart15">
                        <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5 col-xxl-5">
                            <div class="cart11">
                                <div class="cart12">
                                    <a href="#" class="btn">CONTINUE SHOPPING</a>
                                </div>
                                <div class="cart13">
                                    <a href="order.php" class="btn">PROCEED TO CHECKOUT</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
                            <div class="cart14">
                                <p>Subtotal:</p>
                                <h6>$49.14</h6>
                            </div>
                            <div class="cart14">
                                <p>Sales Tax:</p>
                                <h6>For GA orders</h6>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                            <div class="cart16">
                                <p>Your order is safe with us. View our privacy policy and account security information.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'includes/footer.php' ?>