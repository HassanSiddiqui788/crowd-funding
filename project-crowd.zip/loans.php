<?php include 'includes/header.php' ?>
<section class="main-ban" style="background-image: url(images/pic-5.png);">
    <div class="container">
        <div class="row">
            <div class="about-st">
                <h6>GOVERMENT LOANS</h6>
                <h2 class="">GOVERNMENT GRANTS AND LOANS</h2>
            </div>
        </div>
    </div>
</section>

<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-33.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>BUYING FROM <span>THE U.S.</span> GOVERNMENT</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>STATE <span>AND LOCAL </span> GOVERNMENTS</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-34.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>

<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-35.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>FIND AND <span>CONTACT ELECTED</span> OFFICIALS</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php include 'includes/footer.php' ?>