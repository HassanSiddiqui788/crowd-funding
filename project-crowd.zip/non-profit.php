<?php include 'includes/header.php' ?>
<section class="main-ban" style="background-image: url(images/pic-5.png);">
    <div class="container">
        <div class="row">
            <div class="about-st">
                <h6>NON - PROFIT INSTITUTION</h6>
                <h2 class="">DEVELOPMENT ECONOMICS (DEC)</h2>
            </div>
        </div>
    </div>
</section>

<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-22.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>AGRICULTURE <span>AND FOOD</span> SECURITY</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                 
                    <h3>CLIMATE <span>CHANGE </span></h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-23.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-24.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>COMMUNITY <span>DRIVEN</span> DEVELOPMENT</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                 
                    <h3>ECONOMIC <span>GROWTH </span></h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-25.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>

<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-26.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>ENERGY <span>AND</span> EXTRACTIVES</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>ENVIRONMENT <span>AND NATURAL</span> RESOURCES</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-27.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>


<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-28.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>FRAGILITY <span>CONFLICT AND</span> VIOLENCE</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                 
                    <h3>FINANCIAL <span>INCLUSION</span></h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-29.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'includes/footer.php' ?>