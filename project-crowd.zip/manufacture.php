<?php include 'includes/header.php' ?>
<section class="main-ban" style="background-image: url(images/pic-5.png);">
    <div class="container">
        <div class="row">
            <div class="about-st">
                <h6>OUR MANUFACTURERS</h6>
                <h2 class="width-head">OUR MANUFACTURERS YOU NEED TO KNOW</h2>
            </div>
        </div>
    </div>
</section>
<section class="manu-bg">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 1</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 2</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-3">
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 3</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 4</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-3">
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 5</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 6</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-3">
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 7</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 8</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-3">
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 9</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-xl-4">
                <div class="manu-ban">
                    <div class="manu-st">
                        <h4>Manufacturer Profile 10</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                        <div class="orange-btn mt-3">
                            <a href="javascript:;">Download PDF</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'includes/footer.php' ?>