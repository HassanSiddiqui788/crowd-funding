<?php include 'includes/header.php' ?>
<section class="main-ban" style="background-image: url(images/pic-5.png);">
    <div class="container">
        <div class="row">
            <div class="about-st">
                <h6>MARKETING SPECIALIST</h6>
                <h2 class="width-head">BOOST YOUR ROI WITH OUR MARKETING SPECIALIST</h2>
            </div>
        </div>
    </div>
</section>

<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-6.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                    <h3>DELIVER <span>YOUR NEXT BIG </span> CAMPAIGN <span>AND DRIVE</span> SALES <span>IN LESS TIME</span> WITH US.</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                    <h3>TRACK, ANALYZE, <span>AND OPTIMIZE YOUR </span> IMPACT <span>—SO YOU CAN</span> SELL <span>MORE</span> </h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-7.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>



<?php include 'includes/footer.php' ?>