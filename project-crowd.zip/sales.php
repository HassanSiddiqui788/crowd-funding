<?php include 'includes/header.php' ?>
<section class="main-ban" style="background-image: url(images/pic-5.png);">
    <div class="container">
        <div class="row">
            <div class="about-st">
                <h6>SALES REPRESENTATIVE</h6>
                <h2 class="">SALES REPRESENTATIVES FROM ALL OVER THE WORLD ARE AVAILABLE TO HELP YOU</h2>
            </div>
        </div>
    </div>
</section>

<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-10.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>EFFORTLESSLY <span>MANAGE YOUR SALES </span>  PARTNERSHIPS</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                    <h3>IS IT TIME TO  <span>PARTNER </span> WITH YOUR FIRST <span>INDEPENDENT</span> SALESPERSON?</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-11.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>



<?php include 'includes/footer.php' ?>