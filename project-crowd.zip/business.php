<?php include 'includes/header.php' ?>
<section class="main-ban" style="background-image: url(images/pic-5.png);">
    <div class="container">
        <div class="row">
            <div class="about-st">
                <h6>BUSINESS MENTORS</h6>
                <h2 class="">THE DIRECTION TO TAKE CONTROL OF YOUR BUSINESS</h2>
            </div>
        </div>
    </div>
</section>

<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-12.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>1, OVERVIEW</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>2, THE BENEFITS  <span>OF BUSINESS </span> MENTORING</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-13.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="manu-bg">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-14.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                    <h3>3, THE <span>BUSINESS MENTORING</span> SERVICE</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center">

            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div class="deliever-st">
                  
                    <h3>4, BECOMING  <span>A BUSINESS </span> MENTOR</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    <div class="orange-btn mt-4">
                        <a href="javascript:;">GET STARTED</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 col-lg-5 col-xl-5">
                <div class="">
                    <img src="images/pic-15.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'includes/footer.php' ?>